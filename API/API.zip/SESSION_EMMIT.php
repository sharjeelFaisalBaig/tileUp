<?php
require('session.php');
if (isset($_GET['AccessToken'])) {
    if ($_GET['AccessToken'] == 'XXXXXXXXXXXXXXXXXXZAKTILE1926192012sdhsajdhsadjisajdisadksaoeowque843psadSSESION') {
        header('Content-Type: application/json');
        require('cors.php');
        if (isset($_SESSION['CurrCode'])) {
            echo json_encode($_SESSION);
        } else {
            echo json_encode(['session' => 'false']);
        }
    } else {
        echo json_encode(['status' => 'warning', 'message' => 'Try to hit TILE-UP API insecurely ACCESS TOKEN WRONG']);
    }
} else {
    echo json_encode(['status' => 'warning', 'message' => 'Try to hit TILE-UP API insecurely ACCESS TOKEN MISSING']);
}
